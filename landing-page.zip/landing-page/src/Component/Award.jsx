import React from 'react'
import Awards from "../Assets/Award.png"

const Award = () => {
  return (
    <div className='  w-screen flex flex-row justify-center items-center'>
      <img src={Awards} alt="" />
    </div>
  )
}

export default Award
