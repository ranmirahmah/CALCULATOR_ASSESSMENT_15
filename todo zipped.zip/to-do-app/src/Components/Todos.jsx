import React from 'react'
import Todo from './Todo'

const Todos = () => {
  return (
    <div className='  pt-2'>
        <Todo todo ="i want to buy"/>
        <Todo todo ="i want to buy"/>
        <Todo todo ="i want to buy"/>
        <Todo todo ="i want to buy"/>
    </div>
  )
}

export default Todos