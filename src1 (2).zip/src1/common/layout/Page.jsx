import React from 'react'
import AuthLayout from './Authentication'

const PageLayout = () => {
  return (
    <div>
      <AuthLayout />
    </div>
  )
}

export default PageLayout
