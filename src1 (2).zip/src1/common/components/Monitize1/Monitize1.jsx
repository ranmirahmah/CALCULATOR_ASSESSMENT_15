import React from 'react'

const Monitize1 = () => {
  return (
    <div>Monitize1</div>
  )
}

export default Monitize1