import React from 'react'

const Monitize2 = () => {
  return (
    <div>Monitize2</div>
  )
}

export default Monitize2