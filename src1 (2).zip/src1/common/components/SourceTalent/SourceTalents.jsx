import React from 'react'

const SourceTalents = () => {
  return (
    <div>
        
    </div>
  )
}

export default SourceTalents