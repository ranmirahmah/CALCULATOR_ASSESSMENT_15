import React from 'react'

const Home = () => {
  return (
    <div>
      <div className='  px-20'>
        <h1 className=' font-extrabold  text-6xl  pt-24 text-blue-950'>
            Source and Hire Top <br /> Talents
        </h1>
        <p className=' '>
            Unlock a world of possibilities, employ
            engage and employ the <br />fine Talents across fields
            for your projects and <br /> initiatives.
        </p>
      </div>
    </div>
  )
}

export default Home
