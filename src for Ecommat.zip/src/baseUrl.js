// create a base url for your API so that you wont repeat it everytime you want to call the API
export const baseUrl = "https://dummyjson.com/";