let heroCardOne = document.querySelector(".hero-card-1");
// heroCardOne.style.display = "none";
