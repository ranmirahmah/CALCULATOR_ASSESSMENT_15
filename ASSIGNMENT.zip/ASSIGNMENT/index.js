let firstName = "Coded";
let lastName = "Ninjas";
let country = "Nigeria";
let city = "Ikorodu";
let age = 20;
let isMarried = 4>2;
console.log(typeof firstName);
console.log(typeof lastName);
console.log(typeof country);
console.log(typeof city);
console.log(typeof age);
console.log(typeof isMarried);

